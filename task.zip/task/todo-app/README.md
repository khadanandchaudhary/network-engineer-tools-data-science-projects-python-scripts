# To-Do List Application | FreeSchema Assessment

A professional, modern To-Do list application built with Vanilla JS, HTML, CSS, and tightly integrated with the **FreeSchema Data Fabric (`mftsccs-browser`)**.

## Features & Requirements Met
1. **Create Task:** Allows users to add multiple new tasks natively through `MakeTheInstanceConceptLocal`.
2. **List Tasks:** Automatically fetches and listens to the array of existing tasks via `GetCompositionListListener`.
3. **Edit Tasks:** Launches a sleek module to overwrite names through `UpdateComposition` & `PatcherStructure`.
4. **Delete Tasks:** Eliminates tasks and their active connections from the database using `DeleteConceptById`.

## Technology Stack
- **Frontend Core:** Vanilla HTML, CSS (Vibrant dark mode & glassmorphism), standard Javascript.
- **Data Architecture:** FreeSchema Data Fabric
- **Development Tooling:** Vite (to properly bundle Node Module SDK scripts in legacy browsers)

---

## Instructions: How to Run This Application

Follow these steps to preview and test the database connection locally:

### 1. Prerequisites
Ensure you have [Node.js](https://nodejs.org/en) installed on your system.

### 2. Configure Your FreeSchema Environment
Before launching the server, you must authenticate the code with your specific FreeSchema parameters.
1. Open the `script.js` file.
2. At the top of the file (lines 5-9), replace the string placeholders with the API keys provided by your `develop.freeschema.com` portal:
   ```javascript
   const BOOM_URL = "YOUR_BOOM_URL";  // e.g., https://api.boom...
   const AI_URL = "YOUR_AI_URL";
   const BASE_NODE_URL = "YOUR_BASE_NODE_URL";
   const USER_TOKEN = "YOUR_ACCESS_TOKEN";
   const USER_ID = 1234;              // Your integer user ID
   ```

### 3. Install NPM Dependencies
Open your command terminal inside the project directory and run:
```bash
npm install
```

### 4. Start the Development Server
Since standard `file:///` URLs lack module resolution for third-party packages, use Vite to launch the app safely:
```bash
npm run dev
```

### 5. View the Application
Your terminal will output a local network address (typically `http://localhost:5173/`). Click that link to interact with the FreeSchema interconnected application!
