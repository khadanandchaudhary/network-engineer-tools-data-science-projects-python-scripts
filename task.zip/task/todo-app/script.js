import { init, updateAccessToken, MakeTheInstanceConceptLocal, CreateTheConnectionLocal, LocalSyncData, GetCompositionListListener, PatcherStructure, UpdateComposition, DeleteConceptById, PRIVATE, NORMAL } from "mftsccs-browser";

// FreeSchema keys
const BOOM_URL = "YOUR_BOOM_URL";
const AI_URL = "YOUR_AI_URL";
const BASE_NODE_URL = "YOUR_BASE_NODE_URL";
const USER_TOKEN = "YOUR_USER_ACCESS_TOKEN";
const USER_ID = 1; // User ID

// Connect to database
async function bootFreeSchema() {
    try {
        await init(BOOM_URL, AI_URL, "", BASE_NODE_URL);
        updateAccessToken(USER_TOKEN);
        console.log("FreeSchema Initialized!");
        initApp(); // Load tasks
    } catch(err) {
        console.warn("Please replace the placeholder URLs in script.js to fully connect FreeSchema:", err);
        // Fallback mode
        initApp();
    }
}

// App state
let tasks = [];
let currentEditId = null;

// HTML elements
const taskForm = document.getElementById('task-form');
const taskInput = document.getElementById('task-input');
const taskList = document.getElementById('task-list');
const emptyState = document.getElementById('empty-state');
const editModal = document.getElementById('edit-modal');
const editForm = document.getElementById('edit-form');
const editInput = document.getElementById('edit-input');
const cancelEditBtn = document.getElementById('cancel-edit-btn');

// Database API functions

// Create task
async function apiCreateTask(text) {
    // Create base data
    const mainTask = await MakeTheInstanceConceptLocal("the_todo", "", true, USER_ID, PRIVATE);
    // Add task name
    const taskName = await MakeTheInstanceConceptLocal("name", text, false, USER_ID, PRIVATE);
    // Link base and name
    await CreateTheConnectionLocal(mainTask.id, taskName.id, mainTask.id, 1, "", USER_ID);
    // Save to server
    LocalSyncData.SyncDataOnline();
    
    return { id: mainTask.id.toString(), text: text };
}

// Get all tasks 
function apiFetchTasks() {
    return new Promise((resolve) => {
        try {
            GetCompositionListListener("the_todo", USER_ID, 50, 1, NORMAL).subscribe((output) => {
                const formattedTasks = output.map(item => {
                    return {
                        id: item.the_todo.id.toString(),
                        text: item.the_todo.name
                    }
                });
                resolve(formattedTasks);
            });
        } catch (e) {
            console.error("Fetch Listener Error:", e);
            resolve([]); 
        }
    });
}

// Update task
async function apiUpdateTask(id, newText) {
    let patcher = new PatcherStructure();
    patcher.compositionId = Number(id);
    patcher.patchObject = {
        "name": newText
    };
    UpdateComposition(patcher);
    return true;
}

// Remove task
async function apiDeleteTask(id) {
    await DeleteConceptById(Number(id));
    return true;
}

// UI functions

// Start app
async function initApp() {
    try {
        const fetchedTasks = await apiFetchTasks();
        tasks = fetchedTasks;
        renderTasks();
    } catch (error) {
        console.error("Failed to fetch from FreeSchema:", error);
    }
}

taskForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const text = taskInput.value.trim();
    if (!text) return;

    taskInput.disabled = true;
    try {
        const newTask = await apiCreateTask(text);
        tasks.push(newTask);
        renderTasks();
        taskInput.value = '';
    } catch (error) {
        alert("Error saving task! Check your FreeSchema keys in script.js");
    } finally {
        taskInput.disabled = false;
        taskInput.focus();
    }
});

function renderTasks() {
    taskList.innerHTML = '';
    if (tasks.length === 0) {
        emptyState.classList.add('visible');
    } else {
        emptyState.classList.remove('visible');
        tasks.forEach(task => {
            const li = document.createElement('li');
            li.className = 'task-item';
            li.innerHTML = `
                <span class="task-text">${escapeHTML(task.text || 'No Name')}</span>
                <div class="task-actions">
                    <button class="action-btn edit" onclick="window.openEditModal('${task.id}')" aria-label="Edit">
                        <i class="fa-solid fa-pen"></i>
                    </button>
                    <button class="action-btn delete" onclick="window.handleDeleteTask('${task.id}')" aria-label="Delete">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </div>
            `;
            taskList.appendChild(li);
        });
    }
}

window.handleDeleteTask = async (id) => {
    try {
        const previousTasks = [...tasks];
        tasks = tasks.filter(t => t.id !== id);
        renderTasks();
        await apiDeleteTask(id);
    } catch (error) {
        alert("Failed to delete from database");
    }
}

window.openEditModal = (id) => {
    const task = tasks.find(t => t.id === id);
    if (!task) return;
    currentEditId = id;
    editInput.value = task.text;
    editModal.classList.remove('hidden');
    editInput.focus();
}

cancelEditBtn.addEventListener('click', () => {
    editModal.classList.add('hidden');
    currentEditId = null;
    editInput.value = '';
});

editForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const newText = editInput.value.trim();
    if (!newText || !currentEditId) return;

    const btn = editForm.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.textContent = 'Saving...';

    try {
        await apiUpdateTask(currentEditId, newText);
        const taskObj = tasks.find(t => t.id === currentEditId);
        if (taskObj) taskObj.text = newText;
        renderTasks();
        editModal.classList.add('hidden');
    } catch (error) {
        alert("Error updating task!");
    } finally {
        btn.disabled = false;
        btn.textContent = 'Save Changes';
    }
});

function escapeHTML(str) {
    if(!str) return "";
    return str.toString().replace(/[&<>'"]/g, 
        tag => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
        }[tag] || tag)
    );
}

// Connect on load
bootFreeSchema();
